import { Role } from "../types/indexjs";

export const roles = ["ADMIN", "RESIDENT", "SUPERVISOR"];
